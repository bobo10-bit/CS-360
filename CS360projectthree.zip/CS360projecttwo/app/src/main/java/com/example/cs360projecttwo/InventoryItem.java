package com.example.cs360projecttwo;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory")
public class InventoryItem {

    @PrimaryKey(autoGenerate = true)
    public int id;

    private String itemName; // remove 'final'
    private String quantity; // remove 'final'

    public InventoryItem(String itemName, String quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Getters
    public int getId() { return id; }
    public String getItemName() { return itemName; }
    public String getQuantity() { return quantity; }

    // Setters
    public void setItemName(String itemName) { this.itemName = itemName; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
}

