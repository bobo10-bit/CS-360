package com.example.cs360projecttwo;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private LoginDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loggin);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login);
        Button createAccountButton = findViewById(R.id.createAccount);

        db = LoginDatabase.getInstance(this);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> registerUser());
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if(username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = db.userDao().login(username, password);
        if(user != null) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

            // Transition to inventory screen
            Intent intent = new Intent(MainActivity.this, ActivityInventory.class);
            startActivity(intent);
            finish(); // optional: prevents going back to login screen
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if(username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User existingUser = db.userDao().findByUsername(username);
        if(existingUser != null) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        db.userDao().insert(new User(username, password));
        Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
    }
}