package com.example.cs360projecttwo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.text.InputType;
import android.widget.Toast;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ActivityInventory extends AppCompatActivity {

    private InventoryDatabase db;
    private TableLayout tableLayout;
    private EditText editTextItem, editTextQuantity;

    private InventoryItem selectedItem = null;

    private static final String CHANNEL_ID = "inventory_channel";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = InventoryDatabase.getInstance(this);

        // Create notification channel
        createNotificationChannel();

        tableLayout = findViewById(R.id.tableLayout);
        editTextItem = findViewById(R.id.editTextItem);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        FloatingActionButton addButton = findViewById(R.id.floatingActionButton2);

        addButton.setOnClickListener(v -> addItem());

        loadTable();

        // Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.nav_inventory);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_inventory) return true; // Already on inventory
            if (itemId == R.id.nav_settings) {
                startActivity(new Intent(ActivityInventory.this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }

    @SuppressLint("SetTextI18n")
    private void loadTable() {
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // keep header row

        List<InventoryItem> items = db.inventoryDao().getAllItems();

        for (InventoryItem item : items) {
            TableRow row = new TableRow(this);

            // LayoutParams with weight for proper sizing
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    0,
                    TableRow.LayoutParams.WRAP_CONTENT,
                    1 // weight
            );

            // Editable name field
            EditText nameField = new EditText(this);
            nameField.setText(item.getItemName());
            nameField.setPadding(16, 16, 16, 16);
            nameField.setSingleLine(true);
            nameField.setLayoutParams(params);

            // Editable quantity field
            EditText quantityField = new EditText(this);
            quantityField.setText(item.getQuantity());
            quantityField.setPadding(16, 16, 16, 16);
            quantityField.setSingleLine(true);
            quantityField.setInputType(InputType.TYPE_CLASS_NUMBER);
            quantityField.setLayoutParams(params);

            // Delete button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setBackgroundColor(0xFFFF1300);
            deleteButton.setTextColor(0xFFFFFFFF);

            deleteButton.setOnClickListener(v -> {
                db.inventoryDao().delete(item);
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadTable();
            });

            // Update database when name loses focus
            nameField.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    String newName = nameField.getText().toString().trim();
                    if (!newName.equals(item.getItemName())) {
                        item.setItemName(newName);
                        db.inventoryDao().update(item);
                        Toast.makeText(this, "Item name updated", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // Update database when quantity loses focus
            quantityField.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    String newQty = quantityField.getText().toString().trim();
                    if (!newQty.equals(item.getQuantity())) {
                        item.setQuantity(newQty);
                        db.inventoryDao().update(item);
                        Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            row.addView(nameField);
            row.addView(quantityField);
            row.addView(deleteButton);

            tableLayout.addView(row);

            // Low stock notification
            try {
                int qty = Integer.parseInt(item.getQuantity());
                if (qty <= 1) sendLowStockNotification(item.getItemName());
            } catch (NumberFormatException e) {
                // ignore invalid quantity
            }
        }
    }


    private void addItem() {
        String name = editTextItem.getText().toString().trim();
        String quantity = editTextQuantity.getText().toString().trim();

        if (name.isEmpty() || quantity.isEmpty()) {
            Toast.makeText(this, "Enter both item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        InventoryItem item = new InventoryItem(name, quantity);
        db.inventoryDao().insert(item);

        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();

        editTextItem.setText("");
        editTextQuantity.setText("");

        loadTable();
    }

    private void updateItem() {
        if (selectedItem == null) {
            Toast.makeText(this, "Select an item to update", Toast.LENGTH_SHORT).show();
            return;
        }

        String newName = editTextItem.getText().toString().trim();
        String newQuantity = editTextQuantity.getText().toString().trim();

        if (newName.isEmpty() || newQuantity.isEmpty()) {
            Toast.makeText(this, "Enter both item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        selectedItem.setItemName(newName);
        selectedItem.setQuantity(newQuantity);
        db.inventoryDao().update(selectedItem);

        Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
        editTextItem.setText("");
        editTextQuantity.setText("");
        selectedItem = null;

        loadTable();
    }

    // ---------------- Notification ----------------
    private void createNotificationChannel() {
        CharSequence name = "Inventory Alerts";
        String description = "Notifications for low stock items";
        int importance = NotificationManager.IMPORTANCE_DEFAULT;

        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private void sendLowStockNotification(String itemName) {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher) // use your app icon
                .setContentTitle("Low Stock Alert")
                .setContentText(itemName + " has 1 or less in stock!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.notify(itemName.hashCode(), builder.build()); // unique ID per item
    }
}
