package com.example.cs360projecttwo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface InventoryDao {

    @Insert
    void insert(InventoryItem item);

    @Delete
    void delete(InventoryItem item);

    @Query("SELECT * FROM inventory")
    List<InventoryItem> getAllItems();

    @Update
    void update(InventoryItem selectedItem);

}
